import axios from "axios";
import Create from "../pages/Create";
import Delete from "../pages/Delete";
const instance = () => {
  baseUrl = "http://localhost:8080/api/";

};
const movie = ()=>{

  export class 
}

export default movie;
