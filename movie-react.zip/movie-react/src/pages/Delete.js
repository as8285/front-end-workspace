import { useState } from "react";
import { useNavigate } from "react-router-dom";
import movie from "../api/movie";

const Delete = () => {};
export default Delete();
